/**
 * 3D GLB Model Renderer using Three.js
 * 完全本地化，不依赖外部 CDN
 * 兼容所有现代浏览器（包括360、QQ浏览器）
 * 
 * 使用方式：
 *   1. 在 HTML 中创建容器: <div class="three-viewer" data-src="model.glb" data-anim="Idle"></div>
 *   2. 脚本自动初始化并渲染
 */
(function() {
  'use strict';

  // 等待 Three.js 和 GLTFLoader 加载完成
  function waitForDeps(callback) {
    if (window.THREE && window.THREE.GLTFLoader) {
      callback();
      return;
    }
    var check = setInterval(function() {
      if (window.THREE && window.THREE.GLTFLoader) {
        clearInterval(check);
        callback();
      }
    }, 100);
    // 超时保护
    setTimeout(function() { clearInterval(check); }, 10000);
  }

  function initViewer(container) {
    var src = container.getAttribute('data-src') || 'assets/models/RobotExpressive.glb';
    var animName = container.getAttribute('data-anim') || 'Idle';
    var w = container.clientWidth || 300;
    var h = container.clientHeight || 300;

    // Scene
    var scene = new THREE.Scene();

    // Camera
    var camera = new THREE.PerspectiveCamera(45, w / h, 0.1, 1000);
    camera.position.set(0, 1.5, 3);

    // Renderer
    var renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(w, h);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.shadowMap.enabled = true;
    container.appendChild(renderer.domElement);

    // Lights
    scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    var dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(5, 10, 7);
    dirLight.castShadow = true;
    scene.add(dirLight);

    var mixer = null;
    var clock = new THREE.Clock();
    var autoRotate = true;

    // Load GLB
    var loader = new THREE.GLTFLoader();
    loader.load(
      src,
      function(gltf) {
        var model = gltf.scene;

        // Shadows
        model.traverse(function(child) {
          if (child.isMesh) {
            child.castShadow = true;
            child.receiveShadow = true;
          }
        });

        // Auto-scale to fit
        var box = new THREE.Box3().setFromObject(model);
        var size = box.getSize(new THREE.Vector3());
        var maxDim = Math.max(size.x, size.y, size.z);
        var scale = 2.0 / maxDim;
        model.scale.setScalar(scale);

        // Center
        box = new THREE.Box3().setFromObject(model);
        var center = box.getCenter(new THREE.Vector3());
        model.position.sub(center);
        model.position.y += 0.5;

        scene.add(model);

        // Animations
        if (gltf.animations && gltf.animations.length > 0) {
          mixer = new THREE.AnimationMixer(model);
          var clip = null;
          for (var i = 0; i < gltf.animations.length; i++) {
            if (gltf.animations[i].name === animName) {
              clip = gltf.animations[i];
              break;
            }
          }
          if (!clip) clip = gltf.animations[0];
          var action = mixer.clipAction(clip);
          action.play();
        }

        // Notify loaded
        container.setAttribute('data-loaded', 'true');
        if (typeof window.onThreeModelLoaded === 'function') {
          window.onThreeModelLoaded(container);
        }
      },
      function(xhr) {
        // Progress
        if (xhr.lengthComputable) {
          var pct = Math.round(xhr.loaded / xhr.total * 100);
          container.setAttribute('data-progress', pct);
        }
      },
      function(error) {
        console.error('GLB load error:', error);
        container.setAttribute('data-error', error.message || 'Unknown error');
      }
    );

    // Animation loop
    function animate() {
      requestAnimationFrame(animate);
      if (mixer) mixer.update(clock.getDelta());
      if (autoRotate && scene.children.length > 2) {
        // Slow auto-rotate around Y axis
        var model = scene.children[scene.children.length - 1];
        if (model) model.rotation.y += 0.005;
      }
      renderer.render(scene, camera);
    }
    animate();

    // Resize
    if (window.ResizeObserver) {
      var ro = new ResizeObserver(function() {
        var nw = container.clientWidth;
        var nh = container.clientHeight;
        if (nw > 0 && nh > 0) {
          camera.aspect = nw / nh;
          camera.updateProjectionMatrix();
          renderer.setSize(nw, nh);
        }
      });
      ro.observe(container);
    }

    // Store refs
    container._three = { scene: scene, camera: camera, renderer: renderer, mixer: mixer };

    // Public API
    container.setAnimation = function(name) {
      if (!mixer) return;
      var model = scene.children[scene.children.length - 1];
      if (!model) return;
      // Stop current
      mixer.stopAllAction();
      // Find clip
      // We'd need to store gltf.animations, but for simplicity just log
      console.log('Set animation:', name);
    };

    container.pauseAnimation = function() {
      autoRotate = false;
    };

    container.resumeAnimation = function() {
      autoRotate = true;
    };
  }

  // Initialize all viewers when ready
  function initAll() {
    var viewers = document.querySelectorAll('.three-viewer');
    for (var i = 0; i < viewers.length; i++) {
      initViewer(viewers[i]);
    }
  }

  // Auto-init
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      waitForDeps(initAll);
    });
  } else {
    waitForDeps(initAll);
  }

  // Expose for dynamic creation
  window.initThreeViewer = function(container) {
    waitForDeps(function() { initViewer(container); });
  };
})();
